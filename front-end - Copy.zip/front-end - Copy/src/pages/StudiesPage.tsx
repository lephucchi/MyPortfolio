import Studies from '../components/Studies';

const StudiesPage: React.FC = () => {
  return <Studies />;
};

export default StudiesPage;