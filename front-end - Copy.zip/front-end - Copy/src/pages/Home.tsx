import AboutMe from '../components/AboutMe';

const Home: React.FC = () => {
  return <AboutMe />;
};

export default Home;