import Hobbies from '../components/Hobbies';

const HobbiesPage: React.FC = () => {
  return <Hobbies />;
};

export default HobbiesPage;