import Blog from '../components/Blog';

const BlogPage: React.FC = () => {
  return <Blog />;
};

export default BlogPage;