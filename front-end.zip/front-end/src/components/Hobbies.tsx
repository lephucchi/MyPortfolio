import { useState, useEffect } from 'react';
import axios from 'axios';
import type { Hobby } from '../types';

const Hobbies: React.FC = () => {
  const [hobbies, setHobbies] = useState<Hobby[]>([]);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    const fetchHobbies = async () => {
      try {
        const response = await axios.get('http://localhost:5000/hobbies');
        setHobbies(response.data);
      } catch (err: any) {
        setError('Failed to fetch hobbies');
      }
    };
    fetchHobbies();
  }, []);

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4">Hobbies</h1>
      {error && <p className="text-red-500 mb-4">{error}</p>}
      <div className="space-y-4">
        {hobbies.map((hobby) => (
          <div key={hobby.id} className="bg-white p-4 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold">{hobby.name}</h2>
            <p className="text-gray-600">{hobby.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Hobbies;