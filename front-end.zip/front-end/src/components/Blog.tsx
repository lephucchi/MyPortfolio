import { useState, useEffect } from 'react';
import axios from 'axios';
import type { BlogPost } from '../types';
import { useAuth } from '../context/AuthContext';

const Blog: React.FC = () => {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [newPost, setNewPost] = useState({ title: '', content: '' });
  const [error, setError] = useState<string>('');
  const { token } = useAuth();

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const response = await axios.get('http://localhost:5000/blog-posts');
        setPosts(response.data);
      } catch (err: any) {
        setError('Failed to fetch blog posts');
      }
    };
    fetchPosts();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) {
      setError('Please login to create a post');
      return;
    }
    try {
      await axios.post('http://localhost:5000/blog-posts', newPost, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setNewPost({ title: '', content: '' });
      const response = await axios.get('http://localhost:5000/blog-posts');
      setPosts(response.data);
    } catch (err: any) {
      setError('Failed to create post');
    }
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4">Blog</h1>
      {error && <p className="text-red-500 mb-4">{error}</p>}
      {token && (
        <form onSubmit={handleSubmit} className="mb-8">
          <div className="mb-4">
            <label htmlFor="title" className="block text-sm font-medium text-gray-700">
              Title
            </label>
            <input
              type="text"
              name="title"
              id="title"
              value={newPost.title}
              onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
              className="mt-1 p-2 w-full border rounded-md"
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="content" className="block text-sm font-medium text-gray-700">
              Content
            </label>
            <textarea
              name="content"
              id="content"
              value={newPost.content}
              onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
              className="mt-1 p-2 w-full border rounded-md"
              required
            />
          </div>
          <button
            type="submit"
            className="bg-blue-500 text-white p-2 rounded-md hover:bg-blue-600"
          >
            Create Post
          </button>
        </form>
      )}
      <div className="space-y-4">
        {posts.map((post) => (
          <div key={post.id} className="bg-white p-4 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold">{post.title}</h2>
            <p className="text-gray-600">{post.content}</p>
            <p className="text-gray-500 mt-2">Author: {post.author.name}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Blog;